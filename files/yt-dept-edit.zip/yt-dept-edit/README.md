# 編集担当AI社員（yt-dept-edit）配布版

YouTube部署の「編集担当」です。撮った動画から **無音カット → 字幕（SRT）→ 直す所のリスト（最初の30秒・カット候補）** までを作ります。テロップ装飾・BGM・完成動画の書き出しは行いません（編集ソフトで仕上げます）。

## 動作条件

- macOS（Linux でも動く想定。Windows は未確認）
- Claude Code
- Python 3.10 以上
- ffmpeg（`brew install ffmpeg`）
- Python ライブラリ: `pip3 install -r ~/.claude/skills/yt-dept-edit/requirements.txt`
  - Whisper は初回にモデルをダウンロードします（medium で約1.5GB）

## インストール

```bash
unzip yt-dept-edit.zip -d ~/.claude/skills/
pip3 install -r ~/.claude/skills/yt-dept-edit/requirements.txt
```

## 1分の動作確認

```bash
python3 ~/.claude/skills/yt-dept-edit/scripts/edit_review.py selftest
```
`[SUCCESS] selftest 合格` と出れば準備完了です。Claude Code で「この動画の無音を切って、字幕も付けて」と話しかけます。

## 困ったとき

| 症状 | 対処 |
|---|---|
| `silero-vad not installed` | `pip3 install silero-vad`。急ぐときは「ffmpeg エンジンで」と頼む |
| 字幕の誤変換が多い | 「medium モデルで作り直して」と頼む（時間は数倍かかります） |
| 切れすぎて言葉の頭が欠ける | 「無音の最小秒数を 0.8 にして」と頼む |
| 音と映像がずれる | 「libx264 で切り直して」と頼む |

## 同梱物

| ファイル | 中身 |
|---|---|
| `SKILL.md` | AI社員の手順と判断の基準 |
| `references/edit-scope.md` | 担当する所・しない所 |
| `scripts/silence_cutter.py` | 無音カット（Silero VAD / ffmpeg） |
| `scripts/subtitle_generator.py` | 字幕（Whisper＋BudouX） |
| `scripts/edit_review.py` | 直す所のリストの下ごしらえ |

## 配布範囲

セミナー参加者・購入者向けの特典です。再配布はご遠慮ください。※成果には個人差があります。
