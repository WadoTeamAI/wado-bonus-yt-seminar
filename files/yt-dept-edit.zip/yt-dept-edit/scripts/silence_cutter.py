#!/usr/bin/env python3
"""
無音カッター

無音区間を検出し、保持区間のみを結合して出力。
エンジン: silero (Silero VAD, ニューラルネット音声検出) or ffmpeg (silencedetect, 音量ベース)。
再エンコードなし（--codec copy）でデフォルト高速処理。

Usage:
    python3 scripts/silence_cutter.py --input raw/video.mov --output edited/video.mov
    python3 scripts/silence_cutter.py --input raw/video.mov --report
    python3 scripts/silence_cutter.py --input raw/video.mov --output edited/video.mov --engine ffmpeg
    python3 scripts/silence_cutter.py --input raw/video.mov --output edited/video.mov --threshold -30 --min-silence 0.8
    python3 scripts/silence_cutter.py --input raw/video.mov --output edited/video.mov --codec libx264

オプション:
  --engine        silero (default, 高精度VAD) or ffmpeg (音量ベース, 後方互換)
  --threshold     無音判定しきい値 dB (default: -35, ffmpegエンジン用)
  --min-silence   無音最小秒数 (default: 0.5)
  --margin-before 無音開始前マージン秒 (default: 0.15)
  --margin-after  無音終了後マージン秒 (default: 0.08)
  --codec         copy (default, 高速) or libx264 (精密カット)
  --report        カットせず検出結果のみ表示
"""

import argparse
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path


def detect_speech_silero(input_path, min_silence=0.5):
    """Detect silent intervals using Silero VAD (neural network voice detection).

    Returns list of (silence_start, silence_end) tuples, compatible with
    detect_silence() output format.
    """
    try:
        from silero_vad import load_silero_vad, get_speech_timestamps, read_audio
    except ImportError:
        sys.exit("[ERROR] silero-vad not installed. Run: pip3 install silero-vad")

    # Extract 16kHz mono WAV for Silero VAD
    wav_tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    wav_path = wav_tmp.name
    wav_tmp.close()

    try:
        cmd = [
            "ffmpeg", "-y", "-i", str(input_path),
            "-ar", "16000", "-ac", "1", "-f", "wav",
            wav_path,
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            sys.exit(f"[ERROR] ffmpeg WAV extraction failed: {result.stderr[-300:]}")

        # Load model and detect speech
        model = load_silero_vad()
        try:
            audio = read_audio(wav_path)
        except RuntimeError:
            # torchaudio 2.9+ は torchcodec が無いと読めない。16kHz mono の WAV なので標準ライブラリで読む
            import wave
            import torch
            with wave.open(wav_path, "rb") as wf:
                pcm = wf.readframes(wf.getnframes())
            audio = torch.frombuffer(bytearray(pcm), dtype=torch.int16).float() / 32768.0
        speech_timestamps = get_speech_timestamps(
            audio, model,
            sampling_rate=16000,
            min_silence_duration_ms=int(min_silence * 1000),
            speech_pad_ms=30,
        )

        if not speech_timestamps:
            return []

        # Convert speech intervals to silence intervals
        total_samples = len(audio)
        total_duration = total_samples / 16000.0
        silences = []

        # Silence before first speech
        first_start = speech_timestamps[0]["start"] / 16000.0
        if first_start > 0.01:
            silences.append((0.0, first_start))

        # Silences between speech segments
        for i in range(len(speech_timestamps) - 1):
            gap_start = speech_timestamps[i]["end"] / 16000.0
            gap_end = speech_timestamps[i + 1]["start"] / 16000.0
            if gap_end - gap_start >= min_silence:
                silences.append((gap_start, gap_end))

        # Silence after last speech
        last_end = speech_timestamps[-1]["end"] / 16000.0
        if total_duration - last_end > 0.01:
            silences.append((last_end, total_duration))

        return silences
    finally:
        if os.path.exists(wav_path):
            os.unlink(wav_path)


def get_duration(input_path):
    """Get video duration in seconds."""
    cmd = [
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(input_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        sys.exit(f"[ERROR] ffprobe failed: {result.stderr}")
    return float(result.stdout.strip())


def detect_silence(input_path, threshold=-35, min_silence=0.5):
    """Detect silent intervals using ffmpeg silencedetect."""
    cmd = [
        "ffmpeg", "-i", str(input_path),
        "-af", f"silencedetect=noise={threshold}dB:d={min_silence}",
        "-f", "null", "-",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    stderr = result.stderr

    # Parse silence_start and silence_end from ffmpeg stderr
    starts = re.findall(r"silence_start: ([\d.]+)", stderr)
    ends = re.findall(r"silence_end: ([\d.]+)", stderr)

    silences = []
    for i in range(len(starts)):
        s = float(starts[i])
        e = float(ends[i]) if i < len(ends) else None
        silences.append((s, e))

    return silences


def compute_keep_intervals(silences, total_duration, margin_before=0.15, margin_after=0.08):
    """Compute intervals to keep (non-silent segments with margins)."""
    if not silences:
        return [(0, total_duration)]

    keep = []
    prev_end = 0.0

    for silence_start, silence_end in silences:
        if silence_end is None:
            silence_end = total_duration

        # Keep interval: from prev_end to silence_start + margin
        keep_end = silence_start + margin_before
        if keep_end > prev_end:
            keep.append((prev_end, min(keep_end, total_duration)))

        # Next keep starts from silence_end - margin
        prev_end = max(silence_end - margin_after, 0)

    # Remaining segment after last silence
    if prev_end < total_duration:
        keep.append((prev_end, total_duration))

    # Merge overlapping intervals
    merged = []
    for start, end in sorted(keep):
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))

    return merged


def cut_and_concat(input_path, output_path, intervals, codec="copy"):
    """Cut video into intervals and concatenate."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        segment_files = []

        for i, (start, end) in enumerate(intervals):
            segment = tmpdir / f"seg_{i:04d}{input_path.suffix}"
            duration = end - start

            if codec == "copy":
                cmd = [
                    "ffmpeg", "-y", "-i", str(input_path),
                    "-ss", f"{start:.3f}", "-t", f"{duration:.3f}",
                    "-c", "copy", "-avoid_negative_ts", "make_zero",
                    str(segment),
                ]
            else:
                cmd = [
                    "ffmpeg", "-y", "-i", str(input_path),
                    "-ss", f"{start:.3f}", "-t", f"{duration:.3f}",
                    "-c:v", codec, "-c:a", "aac",
                    "-preset", "fast", "-crf", "18",
                    str(segment),
                ]

            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                print(f"[WARN] Segment {i} failed: {result.stderr[-200:]}")
                continue
            segment_files.append(segment)

        if not segment_files:
            sys.exit("[ERROR] No segments produced.")

        # Create concat list
        concat_list = tmpdir / "concat.txt"
        with open(concat_list, "w") as f:
            for seg in segment_files:
                f.write(f"file '{seg}'\n")

        # Concat
        cmd = [
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", str(concat_list),
            "-c", "copy",
            str(output_path),
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            sys.exit(f"[ERROR] Concat failed: {result.stderr[-300:]}")

    return str(output_path)


def format_time(seconds):
    """Format seconds as MM:SS.ms."""
    m, s = divmod(seconds, 60)
    return f"{int(m):02d}:{s:05.2f}"


def main():
    parser = argparse.ArgumentParser(description="Silence Cutter")
    parser.add_argument("--input", "-i", required=True, help="Input video path")
    parser.add_argument("--output", "-o", help="Output video path")
    parser.add_argument("--engine", default="silero", choices=["silero", "ffmpeg"],
                        help="Detection engine: silero (VAD, default) or ffmpeg (volume-based)")
    parser.add_argument("--threshold", type=float, default=-35, help="Silence threshold dB (default: -35, ffmpeg only)")
    parser.add_argument("--min-silence", type=float, default=0.5, help="Min silence duration sec (default: 0.5)")
    parser.add_argument("--margin-before", type=float, default=0.15, help="Keep margin before silence (default: 0.15)")
    parser.add_argument("--margin-after", type=float, default=0.08, help="Keep margin after silence (default: 0.08)")
    parser.add_argument("--codec", default="copy", help="Codec: copy (fast) or libx264 (precise)")
    parser.add_argument("--report", action="store_true", help="Report only, no cutting")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        sys.exit(f"[ERROR] Input not found: {input_path}")

    print(f"[INFO] Analyzing: {input_path.name}")
    total_duration = get_duration(input_path)
    print(f"[INFO] Duration: {format_time(total_duration)} ({total_duration:.2f}s)")

    if args.engine == "silero":
        print(f"[INFO] Detecting silence with Silero VAD (min_silence={args.min_silence}s)...")
        silences = detect_speech_silero(input_path, args.min_silence)
    else:
        print(f"[INFO] Detecting silence with ffmpeg (threshold={args.threshold}dB, min={args.min_silence}s)...")
        silences = detect_silence(input_path, args.threshold, args.min_silence)
    print(f"[INFO] Engine: {args.engine} | Found {len(silences)} silent intervals")

    if args.report or not silences:
        total_silence = sum((e or total_duration) - s for s, e in silences)
        print(f"\n--- Silence Report ---")
        print(f"Total duration:  {format_time(total_duration)}")
        print(f"Silent time:     {format_time(total_silence)} ({total_silence / total_duration * 100:.1f}%)")
        print(f"Content time:    {format_time(total_duration - total_silence)}")
        print(f"\nSilent intervals:")
        for i, (s, e) in enumerate(silences):
            e = e or total_duration
            print(f"  [{i+1:3d}] {format_time(s)} → {format_time(e)} ({e - s:.2f}s)")
        if not args.report and not silences:
            print("[INFO] No silence detected. No cutting needed.")
        return

    if not args.output:
        sys.exit("[ERROR] --output required when not using --report")

    intervals = compute_keep_intervals(silences, total_duration, args.margin_before, args.margin_after)
    keep_duration = sum(e - s for s, e in intervals)
    cut_duration = total_duration - keep_duration

    print(f"[INFO] Keeping {len(intervals)} segments ({format_time(keep_duration)})")
    print(f"[INFO] Cutting {format_time(cut_duration)} ({cut_duration / total_duration * 100:.1f}%)")
    print(f"[INFO] Codec: {args.codec}")

    output = cut_and_concat(input_path, args.output, intervals, args.codec)
    output_duration = get_duration(output)
    print(f"[SUCCESS] Output: {output} ({format_time(output_duration)})")
    print(f"[SUCCESS] Reduced: {format_time(total_duration)} → {format_time(output_duration)} "
          f"(-{format_time(total_duration - output_duration)})")


if __name__ == "__main__":
    main()
