#!/usr/bin/env python3
"""
編集担当AI社員の「直す所のリスト」下ごしらえ（字幕SRT → Markdown）。

字幕（SRT）から、人が見直す材料を機械的に並べるだけ。判断（最初の30秒で
3つが言えているか・どこを切るか）はAI社員（SKILL.md）と本人が行う。

出すもの:
  1. 最初の30秒の書き起こし（時刻つき）
  2. 字幕と字幕の間が長い所（カット候補・既定2.0秒以上）
  3. 言いよどみ（えー・えっと・あのー 等）を含む行
  4. 全体の長さと字幕の行数

使い方:
  python3 edit_review.py review --srt video.srt --out review.md [--head 30] [--gap 2.0]
  python3 edit_review.py selftest

外部送信なし・LLM不使用。
"""

import argparse
import re
import sys
import tempfile
from pathlib import Path

FILLERS = ["えーと", "えっと", "えー", "あのー", "あの、", "まあ", "なんか", "うーん", "そのー"]
TIME_RE = re.compile(r"(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)")


def to_sec(h, m, s, ms):
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000


def fmt(sec):
    m, s = divmod(sec, 60)
    return f"{int(m):02d}:{s:05.2f}"


def parse_srt(text):
    """SRT を [(start, end, text), ...] にする。番号行・空行は無視。"""
    cues = []
    for block in re.split(r"\n\s*\n", text.replace("\r\n", "\n").strip()):
        lines = [ln for ln in block.split("\n") if ln.strip()]
        for i, ln in enumerate(lines):
            m = TIME_RE.search(ln)
            if m:
                g = m.groups()
                body = " ".join(lines[i + 1:]).strip()
                cues.append((to_sec(*g[:4]), to_sec(*g[4:]), body))
                break
    return cues


def build_review(cues, head=30.0, gap=2.0):
    if not cues:
        return "# 直す所のリスト（下ごしらえ）\n\n字幕が0行でした。SRTの中身を確認してください。\n"
    total = cues[-1][1]
    out = ["# 直す所のリスト（下ごしらえ）", "",
           f"- 全体の長さ（字幕の最後まで）: {fmt(total)}",
           f"- 字幕の行数: {len(cues)}", "",
           f"## 1. 最初の{int(head)}秒の書き起こし", "",
           "| 時刻 | 話していること |", "|---|---|"]
    for s, e, t in cues:
        if s >= head:
            break
        out.append(f"| {fmt(s)} | {t.replace('|', '｜')} |")
    out += ["", "判断（AI社員が埋める）: この動画で何が分かるか／誰に向けた動画か／最後まで見ると何が手に入るか", ""]

    out += [f"## 2. 間が{gap:.1f}秒以上ある所（カット候補）", ""]
    rows = []
    for (s1, e1, t1), (s2, e2, t2) in zip(cues, cues[1:]):
        if s2 - e1 >= gap:
            rows.append(f"| {fmt(e1)} → {fmt(s2)} | {s2 - e1:.1f}秒 | {t1[-15:].replace('|', '｜')} |")
    if rows:
        out += ["| 区間 | 長さ | 直前の言葉 |", "|---|---|---|"] + rows
    else:
        out.append("該当なし")
    out += ["", "## 3. 言いよどみを含む行", ""]
    rows = [f"| {fmt(s)} | {t.replace('|', '｜')} |" for s, e, t in cues if any(f in t for f in FILLERS)]
    if rows:
        out += ["| 時刻 | 字幕 |", "|---|---|"] + rows
    else:
        out.append("該当なし")
    out.append("")
    return "\n".join(out)


def cmd_review(args):
    srt = Path(args.srt)
    if not srt.exists():
        sys.exit(f"[ERROR] SRT が見つかりません: {srt}")
    md = build_review(parse_srt(srt.read_text(encoding="utf-8")), args.head, args.gap)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(md, encoding="utf-8")
    print(f"[SUCCESS] {out}")


def cmd_selftest(_args):
    sample = (
        "1\n00:00:00,000 --> 00:00:04,000\nこの動画では、企画を10本出す方法が分かります\n\n"
        "2\n00:00:04,500 --> 00:00:09,000\nえーと、インスタを続けている人に向けた話です\n\n"
        "3\n00:00:12,000 --> 00:00:18,000\n最後まで見ると、使える指示文が手に入ります\n\n"
        "4\n00:00:31,000 --> 00:00:35,000\nでは始めます\n"
    )
    cues = parse_srt(sample)
    assert len(cues) == 4, cues
    md = build_review(cues)
    assert "00:00.00" in md and "では始めます" not in md.split("## 2.")[0], md
    assert "3.0秒" in md, md            # 9.0 → 12.0 の間
    assert "えーと" in md.split("## 3.")[1], md
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "s.srt"
        p.write_text(sample, encoding="utf-8")
        o = Path(d) / "r.md"
        cmd_review(argparse.Namespace(srt=str(p), out=str(o), head=30.0, gap=2.0))
        assert o.exists()
    print("[SUCCESS] selftest 合格")


def main():
    ap = argparse.ArgumentParser(description="字幕から直す所のリストの下ごしらえを作る")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("review")
    r.add_argument("--srt", required=True)
    r.add_argument("--out", required=True)
    r.add_argument("--head", type=float, default=30.0, help="最初の何秒を見るか（既定30）")
    r.add_argument("--gap", type=float, default=2.0, help="カット候補にする間の秒数（既定2.0）")
    r.set_defaults(func=cmd_review)
    sub.add_parser("selftest").set_defaults(func=cmd_selftest)
    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
