#!/usr/bin/env python3
"""
Whisper字幕生成器

openai-whisper でローカル音声認識 → SRT生成 → ffmpeg字幕焼き込み。

Usage:
    python3 scripts/subtitle_generator.py --input edited/video.mov --output-srt subtitles/video.srt
    python3 scripts/subtitle_generator.py --input edited/video.mov --output-srt subtitles/video.srt --model large
    python3 scripts/subtitle_generator.py --input edited/video.mov --output-srt subtitles/video.srt --burn --output-video final/video.mp4
    python3 scripts/subtitle_generator.py --input edited/video.mov --output-srt subtitles/video.srt --burn --output-video final/video.mp4 --style-preset bold

オプション:
  --model          Whisperモデル (tiny/base/small/medium/large, default: medium)
  --language       言語 (default: ja)
  --burn           SRT→動画に字幕焼き込み
  --output-video   焼き込み出力先
  --style-preset   字幕スタイル (default/bold/minimal, default: default)
"""

import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

# --- Style Presets ---
STYLE_PRESETS = {
    "default": {
        "FontName": "Noto Sans JP",
        "FontSize": "24",
        "PrimaryColour": "&H00FFFFFF",  # white
        "OutlineColour": "&H00000000",  # black
        "Outline": "2",
        "Shadow": "1",
        "MarginV": "30",
    },
    "bold": {
        "FontName": "Noto Sans JP",
        "FontSize": "28",
        "PrimaryColour": "&H00FFFFFF",
        "OutlineColour": "&H00000000",
        "Outline": "3",
        "Shadow": "2",
        "MarginV": "40",
    },
    "minimal": {
        "FontName": "Noto Sans JP",
        "FontSize": "20",
        "PrimaryColour": "&H00FFFFFF",
        "OutlineColour": "&H80000000",  # semi-transparent black
        "Outline": "1",
        "Shadow": "0",
        "MarginV": "20",
    },
}


def check_whisper():
    """Check if whisper is available."""
    try:
        import whisper  # noqa: F401
        return True
    except ImportError:
        return False


def transcribe(input_path, model_name="medium", language="ja"):
    """Transcribe audio using Whisper."""
    import whisper

    print(f"[INFO] Loading Whisper model: {model_name}")
    model = whisper.load_model(model_name)

    print(f"[INFO] Transcribing: {input_path}")
    result = model.transcribe(
        str(input_path),
        language=language,
        verbose=False,
        word_timestamps=False,
    )

    segments = result.get("segments", [])
    print(f"[INFO] Transcribed {len(segments)} segments")
    return segments


def split_text_budoux(text, max_chars=20):
    """Split Japanese text at natural phrase boundaries using BudouX.

    Args:
        text: Input text to split.
        max_chars: Maximum characters per line.

    Returns:
        Text with newlines inserted at natural break points.
    """
    try:
        import budoux
    except ImportError:
        return text  # graceful fallback: no splitting

    parser = budoux.load_default_japanese_parser()
    chunks = parser.parse(text)

    lines = []
    current_line = ""
    for chunk in chunks:
        if current_line and len(current_line) + len(chunk) > max_chars:
            lines.append(current_line)
            current_line = chunk
        else:
            current_line += chunk
    if current_line:
        lines.append(current_line)

    return "\n".join(lines)


def segments_to_srt(segments, max_chars_per_line=20):
    """Convert Whisper segments to SRT format with BudouX line splitting."""
    lines = []
    for i, seg in enumerate(segments, 1):
        start = format_srt_time(seg["start"])
        end = format_srt_time(seg["end"])
        text = seg["text"].strip()
        text = split_text_budoux(text, max_chars_per_line)
        lines.append(f"{i}")
        lines.append(f"{start} --> {end}")
        lines.append(text)
        lines.append("")
    return "\n".join(lines)


def format_srt_time(seconds):
    """Format seconds as HH:MM:SS,mmm for SRT."""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def save_srt(srt_content, output_path):
    """Save SRT content to file."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(srt_content)
    print(f"[SUCCESS] SRT saved: {output_path}")


def burn_subtitles(input_video, srt_path, output_video, style_preset="default"):
    """Burn SRT subtitles into video using ffmpeg."""
    output_path = Path(output_video)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    style = STYLE_PRESETS.get(style_preset, STYLE_PRESETS["default"])
    force_style = ",".join(f"{k}={v}" for k, v in style.items())

    # Escape special characters in path for ffmpeg subtitles filter
    srt_escaped = str(srt_path).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")

    cmd = [
        "ffmpeg", "-y",
        "-i", str(input_video),
        "-vf", f"subtitles='{srt_escaped}':force_style='{force_style}'",
        "-c:v", "libx264", "-preset", "fast", "-crf", "18",
        "-c:a", "aac", "-b:a", "192k",
        str(output_path),
    ]

    print(f"[INFO] Burning subtitles: {output_path.name} (style: {style_preset})")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        sys.exit(f"[ERROR] ffmpeg burn failed: {result.stderr[-300:]}")

    print(f"[SUCCESS] Subtitled video: {output_path}")
    return str(output_path)


def main():
    parser = argparse.ArgumentParser(description="Subtitle Generator (Whisper + ffmpeg)")
    parser.add_argument("--input", "-i", required=True, help="Input video/audio path")
    parser.add_argument("--output-srt", "-s", required=True, help="Output SRT path")
    parser.add_argument("--model", "-m", default="medium", help="Whisper model (default: medium)")
    parser.add_argument("--language", "-l", default="ja", help="Language (default: ja)")
    parser.add_argument("--burn", "-b", action="store_true", help="Burn subtitles into video")
    parser.add_argument("--output-video", "-v", help="Output video path (required with --burn)")
    parser.add_argument("--style-preset", default="default", choices=STYLE_PRESETS.keys(),
                        help="Subtitle style preset (default: default)")
    parser.add_argument("--srt-only", action="store_true",
                        help="Skip transcription, use existing SRT for burning")
    parser.add_argument("--max-chars-per-line", type=int, default=20,
                        help="Max characters per subtitle line (BudouX splitting, default: 20)")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        sys.exit(f"[ERROR] Input not found: {input_path}")

    srt_path = Path(args.output_srt)

    if args.srt_only:
        if not srt_path.exists():
            sys.exit(f"[ERROR] SRT not found: {srt_path}")
        print(f"[INFO] Using existing SRT: {srt_path}")
    else:
        if not check_whisper():
            sys.exit("[ERROR] openai-whisper not installed. Run: pip3 install openai-whisper")

        segments = transcribe(input_path, args.model, args.language)
        if not segments:
            print("[WARN] No speech detected.")
            return

        srt_content = segments_to_srt(segments, args.max_chars_per_line)
        save_srt(srt_content, srt_path)

    if args.burn:
        if not args.output_video:
            sys.exit("[ERROR] --output-video required with --burn")
        burn_subtitles(input_path, srt_path, args.output_video, args.style_preset)


if __name__ == "__main__":
    main()
