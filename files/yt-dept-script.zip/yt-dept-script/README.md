# 台本担当AI社員（yt-dept-script）配布版

YouTube部署の「台本担当」です。企画1本から、構成→1パートずつの台本→内容チェック→日本語チェックまで。最初の30秒の型つき。

## 動作条件

- Claude Code（macOS / Windows / Linux）
- スクリプトは使いません（追加のインストールは不要です）

## インストール

```bash
unzip yt-dept-script.zip -d ~/.claude/skills/
```

## 1分の動作確認

Claude Code を開き、「この企画で台本を書いて」「台本をチェックして」 と話しかけます。足りない情報があれば、AI社員の方から質問が返ってきます。

## 困ったとき

| 症状 | 対処 |
|---|---|
| スキルが呼ばれない | `/yt-dept-script` と打って直接呼び出す |
| 毎回同じことを聞かれる | `youtube/channel-profile.md`（チャンネル設定）を作ると読み込みます。雛形は台本担当・チャンネル設計担当に同梱 |
| 数字や実績を書いてほしい | 自分で出典つきで渡した数字だけを使います。AIは数字を作りません |

## 同梱物

| ファイル | 中身 |
|---|---|
| `SKILL.md` | AI社員の手順と判断の基準 |
| `references/channel-profile-template.md` | 判断の根拠・雛形 |
| `references/script-review-checklist.md` | 判断の根拠・雛形 |
| `README.md` | このファイル |

## 配布範囲

セミナー参加者・購入者向けの特典です。再配布はご遠慮ください。※成果には個人差があります。
